create view DEPART_ALL_INFO as
select `a1`.`pk_id`       AS `business_group_id`,
       `a1`.`depart_code` AS `business_group_code`,
       `a1`.`depart_name` AS `business_group_name`,
       `a2`.`pk_id`       AS `business_office_id`,
       `a2`.`depart_code` AS `business_office_code`,
       `a2`.`depart_name` AS `business_office_name`,
       `a3`.`pk_id`       AS `BU_id`,
       `a3`.`depart_code` AS `BU_code`,
       `a3`.`depart_name` AS `BU_name`,
       `a4`.`pk_id`       AS `depart_id`,
       `a4`.`depart_code` AS `depart_code`,
       `a4`.`depart_name` AS `depart_name`
from (((`igdb`.`ig_vfs_depart` `a1` left join `igdb`.`ig_vfs_depart` `a2` on ((`a2`.`depart_parent_code` = `a1`.`pk_id`))) left join `igdb`.`ig_vfs_depart` `a3` on ((`a3`.`depart_parent_code` = `a2`.`pk_id`)))
         left join `igdb`.`ig_vfs_depart` `a4` on ((`a4`.`depart_parent_code` = `a3`.`pk_id`)))
where (`a1`.`depart_type` = 'business_group');

-- comment on column DEPART_ALL_INFO.business_group_id not supported: 數據id

-- comment on column DEPART_ALL_INFO.business_group_code not supported: 部门编号

-- comment on column DEPART_ALL_INFO.business_group_name not supported: 部门名称

-- comment on column DEPART_ALL_INFO.business_office_id not supported: 數據id

-- comment on column DEPART_ALL_INFO.business_office_code not supported: 部门编号

-- comment on column DEPART_ALL_INFO.business_office_name not supported: 部门名称

-- comment on column DEPART_ALL_INFO.BU_id not supported: 數據id

-- comment on column DEPART_ALL_INFO.BU_code not supported: 部门编号

-- comment on column DEPART_ALL_INFO.BU_name not supported: 部门名称

-- comment on column DEPART_ALL_INFO.depart_id not supported: 數據id

-- comment on column DEPART_ALL_INFO.depart_code not supported: 部门编号

-- comment on column DEPART_ALL_INFO.depart_name not supported: 部门名称

